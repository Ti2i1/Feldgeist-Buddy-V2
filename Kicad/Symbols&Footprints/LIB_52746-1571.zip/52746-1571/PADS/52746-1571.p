*PADS-LIBRARY-PART-TYPES-V9*

52746-1571 527461571 I CON 7 1 0 0 0
TIMESTAMP 2026.10.01.18.54.51
"Mouser Part Number" 538-52746-1571
"Mouser Price/Stock" https://www.mouser.co.uk/ProductDetail/Molex/52746-1571?qs=nDwhpid8gJZ2Rlv1mA0S1w%3D%3D
"Manufacturer_Name" Molex
"Manufacturer_Part_Number" 52746-1571
"Description" Molex FFC/FPC SMT Series 0.5mm Pitch 15 Way 1 Row Right Angle SMT Female PCB Housing, Gold over Nickel Plated Contacts
"Datasheet Link" https://www.molex.com/pdm_docs/sd/527461571_sd.pdf
"Geometry.Height" 2.2mm
GATE 1 17 0
52746-1571
1 0 U 1
2 0 U 2
3 0 U 3
4 0 U 4
5 0 U 5
6 0 U 6
7 0 U 7
8 0 U 8
9 0 U 9
10 0 U 10
11 0 U 11
12 0 U 12
13 0 U 13
14 0 U 14
15 0 U 15
MP1 0 U MP1
MP2 0 U MP2

*END*
*REMARK* SamacSys ECAD Model
426970/1515713/2.50/17/4/Connector
